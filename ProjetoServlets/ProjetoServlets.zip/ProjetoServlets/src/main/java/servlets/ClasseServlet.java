package servlets;
import model.Pessoa;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet
public class ClasseServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("O servlet foi chamado.");
        req.getRequestDispatcher("/cadastro.jsp").forward(req, resp);

        String nome = req.getParameter("nome");
        String email = req.getParameter("email");
        String idade = req.getParameter("idade");

        Pessoa pessoa = new Pessoa(nome, email, idade);
//        PrintWriter writer = resp.getWriter();
//        writer.println("<h1>Seu cadastro</h1>");
//        writer.println("<p>Nome: " + pessoa.getNome() + "</p>");
//        writer.println("<p>Email: " + pessoa.getEmail() + "</p>");
//        writer.println("<p>Idade: " + pessoa.getIdade() + "</p>");
//    }
    }
}

